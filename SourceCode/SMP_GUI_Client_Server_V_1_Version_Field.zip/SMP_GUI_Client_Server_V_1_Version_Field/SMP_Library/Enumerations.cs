﻿namespace SMP_Library
{
    public class Enumerations
    {
        public enum SmpVersion
        {
            Version_1_0
        }
        public enum SmpMessageType
        {
            PutMessage,
            GetMessage
        }
    }
}
